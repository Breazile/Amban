This is the default SD card contents for ProffieOS / TeensySaber.

Please see readme and license files in each directory for more information.

To use these files, grab a blank SD card (make sure it's formatted using FAT32)
and drag all the files from this zip file onto the SD card. The top-level
directory of the SD card should contain this file, tracks, TeensySF, etc.
